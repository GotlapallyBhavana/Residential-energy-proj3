import pandas as pd

def load_and_clean(path):
    df = pd.read_csv(path, parse_dates=['timestamp'])
    df = df.set_index('timestamp').resample('H').mean().fillna(method='ffill')
    df['hour'] = df.index.hour
    df['dayofweek'] = df.index.dayofweek
    return df

def add_weather_features(df, weather_df):
    df = df.join(weather_df['temperature'], how='left')
    return df
