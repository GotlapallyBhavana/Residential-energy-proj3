import streamlit as st
import pandas as pd
from src.data_processing import load_and_clean, add_weather_features
from src.model_training import train_forecast_model
from src.anomaly_detection import detect_anomalies
from src.recommendation_engine import recommend
from src.forecast_service import build_forecast_df

@st.cache
def load_data():
    return load_and_clean('data/sample_energy_data.csv')

st.title("Residential Energy Analytics Dashboard")

df = load_data()

# Forecast
model = train_forecast_model(df)
forecast_df = build_forecast_df(model, df)

st.subheader("Forecasted Energy Usage (next 24 h)")
st.line_chart(forecast_df)

# Anomalies
anomalies = detect_anomalies(df)
st.subheader("Detected Inefficiencies / Anomalies")
st.write(f"Found {len(anomalies)} anomaly events")
st.dataframe(anomalies[['energy_kWh']].tail(10))

# Recommendations
st.subheader("Recommendations")
for rec in recommend(df, anomalies):
    st.write("•", rec)

# Raw data
if st.checkbox("Show raw data"):
    st.dataframe(df.tail(50))
