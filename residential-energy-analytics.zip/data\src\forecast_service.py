import pandas as pd

def build_forecast_df(model, df, periods=24):
    last = df.tail(1).index[0]
    future_idx = pd.date_range(last + pd.Timedelta(hours=1), periods=periods, freq='H')
    X_new = pd.DataFrame({
        'hour': future_idx.hour,
        'dayofweek': future_idx.dayofweek,
        'temperature': df['temperature'].iloc[-1]
    }, index=future_idx)
    preds = model.predict(X_new)
    out = pd.DataFrame({'forecast_kWh': preds}, index=future_idx)
    return out
