import os
import azure.functions as func
# Can include code to process incoming blob / stream and run anomaly detection + trigger alert.
