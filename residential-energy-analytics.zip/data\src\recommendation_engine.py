def recommend(df, anomalies):
    recs = []
    for ts, row in anomalies.iterrows():
        msg = f"At {ts}, energy use was abnormal ({row['energy_kWh']:.2f} kWh)."
        recs.append(msg)
    return recs
