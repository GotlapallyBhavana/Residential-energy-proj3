from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error
import pandas as pd

def train_forecast_model(df):
    X = df[['hour', 'dayofweek', 'temperature']]
    y = df['energy_kWh']
    tscv = TimeSeriesSplit(n_splits=5)
    model = RandomForestRegressor(n_estimators=100)
    # Simple split
    train_idx, test_idx = list(tscv.split(X))[-1]
    model.fit(X.iloc[train_idx], y.iloc[train_idx])
    preds = model.predict(X.iloc[test_idx])
    rmse = mean_squared_error(y.iloc[test_idx], preds, squared=False)
    print(f"Forecast RMSE: {rmse:.3f}")
    return model
