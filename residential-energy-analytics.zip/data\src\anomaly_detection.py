from sklearn.ensemble import IsolationForest

def detect_anomalies(df, contamination=0.05):
    model = IsolationForest(contamination=contamination, random_state=42)
    df['anomaly'] = model.fit_predict(df[['energy_kWh']])
    # anomaly = −1 indicates outlier
    anomalies = df[df['anomaly'] == -1]
    return anomalies
